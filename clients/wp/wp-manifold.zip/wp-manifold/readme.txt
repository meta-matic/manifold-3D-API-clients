=== WP Manifold ===
Contributors: pushkar
Stable tag: 1.0
Tested up to: 4.7
Requires at least: 4.6

This is a WordPress plugin for Manifold 3D API.

== Description ==

A plugin to interact with the Manifold 3D API.
